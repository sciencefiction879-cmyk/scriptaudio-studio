=====================================================
ScriptAudio Studio v2.1.0 - Windows Release
=====================================================

ScriptAudio Studio runs seamlessly on Windows 11, 10, 8, and 7!

How to run:
1. Double-click "ScriptAudio Studio.exe" OR "Run_ScriptAudio_Studio.bat".
2. The application opens in a clean, standalone desktop window.
3. No Python, Node.js, or external software needed!
4. Your Google AI Studio API keys and settings are permanently saved.

Enjoy studio-quality Google AI voiceover production!
