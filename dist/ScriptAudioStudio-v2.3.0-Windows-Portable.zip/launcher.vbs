Option Explicit
Dim objFSO, objShell, appDir, htmlPath, appData, userDataDir
Dim browserPath, cmd, edgePaths, chromePaths, bravePaths, p, fileUri

Set objFSO = CreateObject("Scripting.FileSystemObject")
Set objShell = CreateObject("WScript.Shell")

appDir = objFSO.GetParentFolderName(WScript.ScriptFullName)
htmlPath = appDir & "\index.html"

appData = objShell.ExpandEnvironmentStrings("%APPDATA%")
userDataDir = appData & "\ScriptAudioStudio\User Data"

' Ensure persistent user data directory exists
If Not objFSO.FolderExists(appData & "\ScriptAudioStudio") Then
    On Error Resume Next
    objFSO.CreateFolder(appData & "\ScriptAudioStudio")
    On Error GoTo 0
End If

browserPath = ""

' 1. Check Microsoft Edge (Default on Windows 10 & 11)
edgePaths = Array( _
    objShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"), _
    objShell.ExpandEnvironmentStrings("%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"), _
    objShell.ExpandEnvironmentStrings("%LocalAppData%\Microsoft\Edge\Application\msedge.exe") _
)

For Each p In edgePaths
    If objFSO.FileExists(p) Then
        browserPath = p
        Exit For
    End If
Next

' 2. Check Google Chrome if Edge not found
If browserPath = "" Then
    chromePaths = Array( _
        objShell.ExpandEnvironmentStrings("%ProgramFiles%\Google\Chrome\Application\chrome.exe"), _
        objShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"), _
        objShell.ExpandEnvironmentStrings("%LocalAppData%\Google\Chrome\Application\chrome.exe") _
    )
    For Each p In chromePaths
        If objFSO.FileExists(p) Then
            browserPath = p
            Exit For
        End If
    Next
End If

' 3. Check Brave Browser
If browserPath = "" Then
    bravePaths = Array( _
        objShell.ExpandEnvironmentStrings("%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe"), _
        objShell.ExpandEnvironmentStrings("%LocalAppData%\BraveSoftware\Brave-Browser\Application\brave.exe") _
    )
    For Each p In bravePaths
        If objFSO.FileExists(p) Then
            browserPath = p
            Exit For
        End If
    Next
End If

' Launch application window
If browserPath <> "" Then
    fileUri = "file:///" & Replace(htmlPath, "\", "/")
    cmd = """" & browserPath & """ --app=""" & fileUri & """ --window-size=1440,940 --user-data-dir=""" & userDataDir & """ --allow-file-access-from-files --no-first-run --no-default-browser-check"
    objShell.Run cmd, 1, True
Else
    ' Fallback to default Windows web browser
    objShell.Run "rundll32.exe url.dll,FileProtocolHandler """ & htmlPath & """", 1, True
End If
