@echo off
title ScriptAudio Studio
cd /d "%~dp0"

:: Prefer silent VBScript launcher if wscript is available
if exist "%SystemRoot%\System32\wscript.exe" (
    "%SystemRoot%\System32\wscript.exe" //nologo "%~dp0launcher.vbs"
    exit /b 0
)

set "HTML_PATH=%~dp0index.html"
set "USER_DATA=%APPDATA%\ScriptAudioStudio\User Data"

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%HTML_PATH:\=/%" --window-size=1440,940 --user-data-dir="%USER_DATA%" --allow-file-access-from-files
    exit /b 0
)

if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="file:///%HTML_PATH:\=/%" --window-size=1440,940 --user-data-dir="%USER_DATA%" --allow-file-access-from-files
    exit /b 0
)

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%HTML_PATH:\=/%" --window-size=1440,940 --user-data-dir="%USER_DATA%" --allow-file-access-from-files
    exit /b 0
)

start "" "%HTML_PATH%"
exit /b 0
